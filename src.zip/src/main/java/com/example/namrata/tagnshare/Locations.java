package com.example.namrata.tagnshare;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;


public class Locations extends Fragment {

     ImageView mTravelbtn, mShopbtn, mFoodbtn, mCampbtn;
     String category;


     View mMainView;


    public Locations() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mMainView= inflater.inflate(R.layout.fragment_locations, container, false);

        mCampbtn = (ImageView) mMainView.findViewById(R.id.camp);
        mTravelbtn = (ImageView) mMainView.findViewById(R.id.travel);
        mShopbtn = (ImageView) mMainView.findViewById(R.id.shop);
        mFoodbtn = (ImageView) mMainView.findViewById(R.id.hotel);

        mCampbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CharSequence options[] = new CharSequence[]{"Your's Location" , "Friends Location"};

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

                builder.setTitle("Select Options");
                builder.setItems(options ,new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        switch (i) {
                            case 0:
                                category = "Camp spot";
                                Intent showCategoryLocations1 = new Intent(getActivity(), DisplayImagesActivity.class);
                                showCategoryLocations1.putExtra("category", category);
                                startActivity(showCategoryLocations1);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                            case 1:
                                category = "Camp spot";
                                Intent showCategoryLocations2 = new Intent(getActivity(), Temp.class);
                                showCategoryLocations2.putExtra("category", category);
                                startActivity(showCategoryLocations2);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                        }
                    }
                });
                builder.show();

            }

                });

                /*category = "Camp spot";
                Intent showCategoryLocations = new Intent(getActivity(),FriendsUserCategoryTabbedActivity.class);
                showCategoryLocations.putExtra("category",category);
                startActivity(showCategoryLocations);
                Toast.makeText(getContext()," "+category,Toast.LENGTH_SHORT).show();
*/



        mTravelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CharSequence options[] = new CharSequence[]{"Your's Location" , "Friends Location"};

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

                builder.setTitle("Select Options");
                builder.setItems(options ,new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        switch (i) {
                            case 0:
                                category = "Travelling spot";
                                Intent showCategoryLocations1 = new Intent(getActivity(), DisplayImagesActivity.class);
                                showCategoryLocations1.putExtra("category", category);
                                startActivity(showCategoryLocations1);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                            case 1:
                                category = "Travelling spot";
                                Intent showCategoryLocations2 = new Intent(getActivity(), Temp.class);
                                showCategoryLocations2.putExtra("category", category);
                                startActivity(showCategoryLocations2);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                        }
                    }
                });
                builder.show();

            }
        });

        mFoodbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CharSequence options[] = new CharSequence[]{"Your's Location", "Friends Location"};

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

                builder.setTitle("Select Options");
                builder.setItems(options, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        switch (i) {
                            case 0:
                                category = "Hotel spot";
                                Intent showCategoryLocations1 = new Intent(getActivity(), DisplayImagesActivity.class);
                                showCategoryLocations1.putExtra("category", category);
                                startActivity(showCategoryLocations1);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                            case 1:
                                category = "Hotel spot";
                                Intent showCategoryLocations2 = new Intent(getActivity(), Temp.class);
                                showCategoryLocations2.putExtra("category", category);
                                startActivity(showCategoryLocations2);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                        }
                    }
                });
                builder.show();


            }
        });

        mShopbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CharSequence options[] = new CharSequence[]{"Your's Location", "Friends Location"};

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

                builder.setTitle("Select Options");
                builder.setItems(options, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        switch (i) {
                            case 0:
                                category = "Shopping spot";
                                Intent showCategoryLocations1 = new Intent(getActivity(), DisplayImagesActivity.class);
                                showCategoryLocations1.putExtra("category", category);
                                startActivity(showCategoryLocations1);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                            case 1:
                                category = "Shopping spot";
                                Intent showCategoryLocations2 = new Intent(getActivity(), Temp.class);
                                showCategoryLocations2.putExtra("category", category);
                                startActivity(showCategoryLocations2);
                                Toast.makeText(getContext(), " " + category, Toast.LENGTH_SHORT).show();
                                break;

                        }
                    }
                });
                builder.show();


            }
        });

        return mMainView;
    }


}

