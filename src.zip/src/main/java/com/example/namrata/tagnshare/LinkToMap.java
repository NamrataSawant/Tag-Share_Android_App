package com.example.namrata.tagnshare;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;


public class LinkToMap extends Fragment {

    private View mMainView;
    private ImageView mSendToMap;
    private ImageView mCreatePath;
    private ImageView mMakeSchedule;


    public LinkToMap() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mMainView = inflater.inflate(R.layout.fragment_link_to_map, container, false);

        mSendToMap = (ImageView) mMainView.findViewById(R.id.link_to_map_btn);
        mSendToMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent mapIntent = new Intent(getActivity(),MapsActivity.class);
                startActivity(mapIntent);

            }
        });

        mCreatePath = (ImageView) mMainView.findViewById(R.id.link_to_create_path_btn);
        mCreatePath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent mapIntent = new Intent(getActivity(),LocationTracker.class);
                startActivity(mapIntent);

            }
        });

        mMakeSchedule = (ImageView) mMainView.findViewById(R.id.link_to_make_schedule_btn);
        mMakeSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent mapIntent = new Intent(getActivity(),LocationAlertActivity.class);
                startActivity(mapIntent);

            }
        });

        return mMainView;


    }



}
