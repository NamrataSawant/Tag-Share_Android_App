package com.example.namrata.tagnshare;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.Locale;

public class MoreDetailsActivity extends AppCompatActivity {
    List<Address> addresses;
    Geocoder geocoder;
    String storelat,imageUploadId;
    String storelng;
    Uri FilePathUri;
    Uri VideoPathUri;
    String TempImageName,imageURL="null",TempComment;
    String videoUrl="null",category,rating,user,uid;
    public TextView imageNameTextViewLocation,address,videoURL;
    public RatingBar ratingBar;
    public TextView imageNameTextView,user_name;
    public ImageView imageView;
    public ImageView shareBtn,deleteBtn;

    FirebaseUser mAuth;
    DatabaseReference mUserDataReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_details);

        Bundle extras = getIntent().getExtras();
         TempImageName = extras.getString("name");
         category = extras.getString("category");
         TempComment = extras.getString("comment");
         imageURL = extras.getString("imageUrl");
         videoUrl = extras.getString("videoUrl");
         storelng = extras.getString("longitude");
         storelat = extras.getString("latitude");
         rating = extras.getString("rating");
         user = extras.getString("user");
         uid = extras.getString("uid");
         imageUploadId=extras.getString("imageUploadId");
         mAuth= FirebaseAuth.getInstance().getCurrentUser();


       // Toast.makeText(getApplicationContext(), "Text:" + imageURL, Toast.LENGTH_LONG).show();

        imageView = (ImageView)findViewById(R.id.imageView);
        videoURL = (TextView)findViewById(R.id.videoUrl);
        videoURL.setMovementMethod(LinkMovementMethod.getInstance());
        ratingBar=(RatingBar)findViewById(R.id.ratingBar2);
        address = (TextView) findViewById(R.id.address);
        imageNameTextView = (TextView)findViewById(R.id.ImageNameTextView);
        imageNameTextViewLocation = (TextView)findViewById(R.id.ImageNameTextView2);
        user_name = (TextView)findViewById(R.id.username);
        shareBtn=(ImageView) findViewById(R.id.shareBtn);
        deleteBtn=(ImageView)findViewById(R.id.deleteBtn);
        ratingBar.setRating(Float.valueOf(rating));
        imageNameTextView.setText(TempImageName);
        user_name.setText("Uploaded by "+user);
        final Double latitude,longitude;
        latitude=Double.valueOf(storelat) ;
        imageNameTextViewLocation.setText("Comment: "+TempComment);
        longitude=Double.valueOf(storelng) ;

        try {
            geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

            addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
        } catch (IOException e) {
            e.printStackTrace();
        }
        String address1 = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
        String city = addresses.get(0).getLocality();
        String state = addresses.get(0).getAdminArea();
        String country = addresses.get(0).getCountryName();
        String postalCode = addresses.get(0).getPostalCode();
        Spanned Text = Html.fromHtml(" "+address1+" , "+city+" , "+state+" , "+country+" , "+postalCode);
        address.setClickable(true);
        address.setMovementMethod(LinkMovementMethod.getInstance());
        address.setText("Location: "+Text);

        if(videoUrl!=null) {
          videoURL.setText("Video link: "+videoUrl);
        }
        if(imageURL!=null) {
            //Loading image from Glide library.
            Glide.with(getApplicationContext()).load(imageURL).into(imageView);
        }
//Toast.makeText(getApplicationContext(),"uid="+uid+"mAuth="+mAuth.getUid(),Toast.LENGTH_LONG).show();
        mUserDataReference = FirebaseDatabase.getInstance().getReference().child("Locations")
                .child(mAuth.getUid()).child(imageUploadId);
        shareBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                shareLocation();
            }
        });
        final String currentUser=mAuth.getUid();
        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!currentUser.equals(uid))
                {
                   Toast.makeText(getApplicationContext(),"You cannot delete this post!",Toast.LENGTH_SHORT).show();

                }
                else
                {
                    mUserDataReference.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Intent intent=new Intent(MoreDetailsActivity.this,RecyclerViewAdapter.class);
                            startActivity(intent);
                        }
                    });

                }
            }
        });
    }

    public void shareLocation(){

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String whatsAppMessage;
                if(imageURL!=null && videoUrl==null)
                {

                    //Do something after 100ms
                    whatsAppMessage ="http://maps.google.com/maps?saddr="+ storelat + "," + storelng+
                            " \nPlace: "+TempImageName+"\n Image link: "+imageURL+"\n Longitude: "+storelat+"\n Latitude: "+storelng+
                            "\n Comment: "+TempComment+"\n Rating: "+rating+"\n Video link: No video";
                    //String whatsAppMessage = "http://maps.google.com/maps?saddr=" + storelat + "," + storelng;


                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
                    sendIntent.setType("text/plain");

                /*    sendIntent.putExtra(Intent.EXTRA_STREAM,FilePathUri);
                    sendIntent.setType("image*//*");*/

                    startActivity(Intent.createChooser(sendIntent,"Share via"));
                    //startActivity(sendIntent);
                }

                else if(videoUrl!=null && imageURL==null)
                {
                    //Do something after 100ms
                    whatsAppMessage ="http://maps.google.com/maps?saddr="+ storelat + "," + storelng+
                            " \nPlace: "+TempImageName+"\n Image link: No image"+"\n Longitude: "+storelat+"\n Latitude: "+storelng+
                            "\n Comment: "+TempComment+"\n Rating: "+rating+"\n Video link: "+videoUrl;
                    //String whatsAppMessage = "http://maps.google.com/maps?saddr=" + storelat + "," + storelng;
                    VideoPathUri = Uri.parse(videoUrl);

                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
                    sendIntent.setType("text/plain");

                  /*  sendIntent.putExtra(Intent.EXTRA_STREAM,VideoPathUri);
                    sendIntent.setType("video*//*");*/

                    startActivity(Intent.createChooser(sendIntent,"Share via"));
                    //startActivity(sendIntent);

                }
                else if(videoUrl!=null && imageURL!=null)
                {
                    //Do something after 100ms
                    whatsAppMessage ="http://maps.google.com/maps?saddr="+ storelat + "," + storelng+
                            " \nPlace: "+TempImageName+"\n Image link: "+imageURL+"\n Longitude: "+storelat+"\n Latitude: "+storelng+
                            "\n Comment: "+TempComment+"\n Rating: "+rating+"\n Video link: "+videoUrl;
                    //String whatsAppMessage = "http://maps.google.com/maps?saddr=" + storelat + "," + storelng;
                    FilePathUri = Uri.parse(imageURL);
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
                    sendIntent.setType("text/plain");

                   /* sendIntent.putExtra(Intent.EXTRA_STREAM,FilePathUri);
                    sendIntent.setType("image*//*");*/

                    startActivity(Intent.createChooser(sendIntent,"Share via"));
                    //startActivity(sendIntent);
                }


            }
        }, 2000);

    }
}
