package com.example.namrata.tagnshare;

/**
 * Created by Dell on 14/01/2018.
 */

public class Friends {
    public String date; // this name should be same as database entry.
    public String name;
    public String thumb;


    public Friends(){

    }

    public Friends(String date, String name, String thumb){
        this.date =date;
        this.name = name;
        this.thumb=thumb;
    }

    public String getDate(){ return date; }

    public void setDate(String date) { this.date = date;}

    public String getName(){ return name; }

    public void setName(String name) { this.name = name;}

    public String getThumb(){ return thumb; }

    public void setThumb(String thumb) { this.thumb = thumb;}



}
