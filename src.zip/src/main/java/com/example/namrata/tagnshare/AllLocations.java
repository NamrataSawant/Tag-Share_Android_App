package com.example.namrata.tagnshare;

/**
 * Created by Dell on 27/01/2018.
 */

public class AllLocations {

    public String imageName;
    //public String ;
    //public String thumb;

    public AllLocations(){}

    public AllLocations(String LocationName)
    {
        this.imageName = LocationName;

    }
    public String getimageName(){ return imageName; }

    public void setimageName(String imageName) { this.imageName = imageName;}




}


