package com.example.namrata.tagnshare;

/**
 * Created by Namrata on 12-Jan-18.
 */

public class ImageUploadInfo {

    public String imageName;
    public String latitude;
    public String longitude;
    public String imageURL;
    public String videoUrl;
    public String rating;
    public String comment;
    public String category;
    public String uid;
    public String imageUploadId;


    public ImageUploadInfo() {

    }

    public ImageUploadInfo(String uid,String name,String imageURL,String videoUrl,String rating,String comment,
                           String latitude,String longitude,String category,String imageUploadId) {

        this.imageName = name;
        this.imageURL= imageURL;
        this.videoUrl=videoUrl;
        this.latitude=latitude;
        this.longitude=longitude;
        this.rating= rating;
        this.comment=comment;
        this.category=category;
        this.uid=uid;
        this.imageUploadId=imageUploadId;
    }

    public String getCategory() {
       return category;
  }

    public String getVideoUrl() {
        return videoUrl;
    }

    public String getImageName() {
        return imageName;
    }

    public String getImageURL() {
        return imageURL;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public String getComment() {
        return comment;
    }

    public String getRating() {
        return rating;
    }

    public String getUid() {
        return uid;
    }

    public String getImageUploadId() {
        return imageUploadId;
    }

    public void setImageURL(String path) {
        imageURL =path;
    }



}
