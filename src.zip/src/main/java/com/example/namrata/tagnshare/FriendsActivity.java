package com.example.namrata.tagnshare;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class FriendsActivity extends AppCompatActivity {

    private RecyclerView mFriendslist;

    private DatabaseReference mFriendsDatabase;
    private DatabaseReference mUsersDatabase;
    private FirebaseAuth mAuth;

    private String mCurrent_user_id;

    private String mLocationId, mLocationName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
        mFriendslist=(RecyclerView)findViewById(R.id.friends_list);
        mAuth = FirebaseAuth.getInstance();

        mCurrent_user_id=mAuth.getCurrentUser().getUid();
        mFriendsDatabase= FirebaseDatabase.getInstance().getReference().child("Friends").child(mCurrent_user_id);
        // mFriendsDatabase.keepSynced(true);
        mUsersDatabase= FirebaseDatabase.getInstance().getReference().child("Users");
        //mUsersDatabase.keepSynced(true);

        mFriendslist.setHasFixedSize(true);
        mFriendslist.setLayoutManager(new LinearLayoutManager(this));

        mLocationId = getIntent().getStringExtra("location_id");
        mLocationName = getIntent().getStringExtra("location_name");


    }

    @Override
    public void onStart(){
        super.onStart();

        FirebaseRecyclerAdapter<Friends, FriendsFragment.FriendsViewHolder> friendsRecyclerViewAdapter = new FirebaseRecyclerAdapter<Friends, FriendsFragment.FriendsViewHolder>(
                Friends.class,
                R.layout.users_single,
                FriendsFragment.FriendsViewHolder.class,
                mFriendsDatabase
        )
        {
            @Override
            protected void populateViewHolder(final FriendsFragment.FriendsViewHolder friendsviewHolder, final Friends friends, int i) {

                friendsviewHolder.setDate(friends.getDate());

                final String list_user_id = getRef(i).getKey();
                mUsersDatabase.child(list_user_id).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        final String userName = dataSnapshot.child("name").getValue().toString();
                        String userThumb = dataSnapshot.child("thumb_image").getValue().toString();
                        // String userOnline = dataSnapshot.child("online").getValue().toString();

                        if(dataSnapshot.hasChild("online")){

                            String userOnline = dataSnapshot.child("online").getValue().toString();
                            friendsviewHolder.setOnlineStatus(userOnline);
                        }

                        friendsviewHolder.setName(userName);
                        friendsviewHolder.setThumb(userThumb,getApplicationContext());
                        // friendsviewHolder.setOnlineStatus(userOnline);

                        Toast.makeText(FriendsActivity.this,mLocationId+ " "+ mLocationName, Toast.LENGTH_LONG).show();


                        friendsviewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                CharSequence options[] = new CharSequence[]{"Open Profile" , "Send message"};

                                AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());

                                builder.setTitle("Select Options");
                                builder.setItems(options ,new DialogInterface.OnClickListener(){

                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i){


                                                Intent chat_intent=new Intent(FriendsActivity.this,ChatActivity.class);
                                                chat_intent.putExtra("user_id",list_user_id);
                                                chat_intent.putExtra("user_name",userName);  //passing key reteived to chat activity so that all the information
                                                chat_intent.putExtra("location_id",mLocationId);
                                                chat_intent.putExtra("location_name",mLocationName);
                                                startActivity(chat_intent);




                                    }

                                });

                                builder.show();

                            }
                        });

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });


            }
        };

        mFriendslist.setAdapter(friendsRecyclerViewAdapter);

    }

    public static class FriendsViewHolder extends RecyclerView.ViewHolder{

        View mView;

        public FriendsViewHolder(View itemView){
            super(itemView);

            mView = itemView;
        }

        public void setDate(String date){

            TextView userNameView = (TextView) mView.findViewById(R.id.users_single_status);
            userNameView.setText(date);
        }
        public void setName(String name){

            TextView userNameView = (TextView) mView.findViewById(R.id.users_single_name);
            userNameView.setText(name);
        }

        public void setThumb(String thumb_image,Context ctx){

            CircleImageView userImageView= (CircleImageView)mView.findViewById(R.id.users_single_image);
            Picasso.with(ctx).load(thumb_image).placeholder(R.drawable.default_avatar).into(userImageView);
        }

        /*public void setOnlineStatus(boolean online_status){

             ImageView userOnlineIcon =(ImageView)mView.findViewById(R.id.users_single_online_icon);

             if(online_status){

                   userOnlineIcon.setVisibility(View.VISIBLE);
             }
             else{
                   userOnlineIcon.setVisibility(View.INVISIBLE);
             }


         }*/
        public void setOnlineStatus(String online_status){

            ImageView userOnlineIcon =(ImageView)mView.findViewById(R.id.users_single_online_icon);

            if(online_status.equals("true")){

                userOnlineIcon.setVisibility(View.VISIBLE);
            }
            else{
                userOnlineIcon.setVisibility(View.INVISIBLE);
            }


        }





    }

}
