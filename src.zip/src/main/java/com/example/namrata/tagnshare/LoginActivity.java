package com.example.namrata.tagnshare;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

public class LoginActivity extends AppCompatActivity {

     private TextInputLayout email;
     private TextInputLayout pass;
    private Button login;

    private Toolbar tool;

    private FirebaseAuth mAuth;
    private DatabaseReference mUserRef;

    private ProgressDialog loginProgressD;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email=(TextInputLayout)findViewById(R.id.login_email);
        pass=(TextInputLayout)findViewById(R.id.login_password);
        login=(Button)findViewById(R.id.Login_btn);

        loginProgressD=new ProgressDialog(this);

        tool=(Toolbar)findViewById(R.id.login_page_toolbar) ;

        setSupportActionBar(tool);
        getSupportActionBar().setTitle("Login");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        //getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);


        mAuth = FirebaseAuth.getInstance();


        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                try {
                    String memail = email.getEditText().getText().toString();
                    String mpass=pass.getEditText().getText().toString();


                if( !TextUtils.isEmpty(memail) || !TextUtils.isEmpty(mpass)){

                    loginProgressD.setTitle("Logging in");
                    loginProgressD.setMessage("Please wait");
                    loginProgressD.setCanceledOnTouchOutside(true);
                    loginProgressD.show();
                    Toast.makeText(LoginActivity.this, memail+" "+mpass, Toast.LENGTH_LONG).show();


                      login_user(memail,mpass);

                }


                } catch (Exception e) {

                    Toast.makeText(LoginActivity.this, "Inside Catch error", Toast.LENGTH_SHORT).show();

                    e.printStackTrace();
                }


            }
        });
    }

    private void login_user(String memail, String mpass) {

        Toast.makeText(LoginActivity.this, "Inside Login user function"+memail+" "+mpass, Toast.LENGTH_LONG).show();

        mAuth.signInWithEmailAndPassword(memail,mpass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {


                            loginProgressD.dismiss();
                            // Sign in success, update UI with the signed-in user's information

                            Intent i=new Intent(LoginActivity.this,MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);  //whenever in main activity after logged in should not
                                                                                                          // go to login activity or any other back activity.Instead should close the app.
                            startActivity(i);

                            finish();

                        } else {

                            loginProgressD.hide();
                            // If sign in fails, display a message to the user.

                            Toast.makeText(LoginActivity.this, "Cannot sign in please try again", Toast.LENGTH_SHORT).show();

                        }


                    }
                });


    }
    }


