package com.example.namrata.tagnshare;


import android.app.MediaRouteButton;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class sample extends AppCompatActivity {
    ImageButton camButton,save,share;
    ImageView ivGalImg;
    VideoView video;
    ImageButton btnGal;
    EditText imageName;
    String storelat;
    String storelng;
    RatingBar ratingBar;
    EditText Comment;
    ImageView shop,travel,hotel,camp;
    TextView show;
    // Folder path for Firebase Storage.
    String Storage_Path = "All_Image_Uploads/";

    // Root Database Name for Firebase Database.
    //String Database_Path = "All_Image_Uploads_Database";
    // Creating URI.
    Uri FilePathUri,VideoPathUri;
    double lat ;
    double lng ;
    String TempImageName,imageURL="null",TempComment;
    String videoUrl="null";
    // Creating StorageReference and DatabaseReference object.
    StorageReference storageReference;
    DatabaseReference databaseReference,mUsersDatabase;
    FirebaseUser mAuth;
    ProgressDialog progressDialog ;
    Float rating;
    String category;
    String user;
    ImageButton btnVideo;
    String ImageUploadId;
    StorageReference storageReferenceimage, storageReferencevideo;
    int shareCount=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample);
        btnGal=(ImageButton)findViewById(R.id.btnGallary);
        btnVideo=(ImageButton)findViewById(R.id.btnVideo);
        ivGalImg=(ImageView) findViewById(R.id.ivImage);
        video=(VideoView) findViewById(R.id.videoView);
        shop=(ImageView) findViewById(R.id.shop);
        camp=(ImageView) findViewById(R.id.camp);
        travel=(ImageView) findViewById(R.id.travel);
        hotel=(ImageView) findViewById(R.id.hotel);
        show=(TextView)findViewById(R.id.show);
        camButton=(ImageButton)findViewById(R.id.camButton);
        imageName=(EditText)findViewById(R.id.imageName);
        save=(ImageButton)findViewById(R.id.save);
        share=(ImageButton)findViewById(R.id.share);
        ratingBar=(RatingBar)findViewById(R.id.ratingBar);
        Comment=(EditText)findViewById(R.id.Comment);
        // Assign FirebaseStorage instance to storageReference.
        storageReference = FirebaseStorage.getInstance().getReference();

        mAuth= FirebaseAuth.getInstance().getCurrentUser();

        // Assign FirebaseDatabase instance with root database name.
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Locations");
        // Assigning Id to ProgressDialog.
        progressDialog = new ProgressDialog(sample.this);
        Bundle extras = getIntent().getExtras();
        lat = extras.getDouble("latitude");
        lng = extras.getDouble("longitude");
       // Toast.makeText(sample.this,"Latlng:\n" + lat + " : " +
         //       lng,Toast.LENGTH_LONG).show();
        btnGal.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View arg0)
            {
                openGallery();
            }
        });
        btnVideo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View arg0)
            {
                openGalleryVideo();
            }
        });
        EnableRuntimePermission();
        camp.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText("Camp spot");
                category="Camp spot";
            }
        });
        hotel.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText("Hotel spot");
                category="Hotel spot";

            }
        });
        travel.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText("Travelling spot");
                category="Travelling spot";


            }
        });
        shop.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                show.setText("Shopping spot");
                category="Shopping spot";


            }
        });
        share.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Calling method to upload selected image on Firebase storage.
                UploadImageFileToFirebaseStorage();
                shareCount=1;
            }
        });
        camButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                startActivityForResult(intent, 7);
            }
        });

        // Adding click listener to Upload image button.
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Calling method to upload selected image on Firebase storage.
                UploadImageFileToFirebaseStorage();
                Intent mapsClonedIntent = new Intent(sample.this,MapsClonedActivity.class);
                mapsClonedIntent.putExtra("latitude", lat);
                mapsClonedIntent.putExtra("longitude", lng);
                startActivity(mapsClonedIntent);

            }
        });

        ImageButton Close = (ImageButton)findViewById(R.id.closeButton);
        Close.setOnClickListener(cancel_button);
    }
    private View.OnClickListener cancel_button = new View.OnClickListener() {
        public void onClick(View v) {
           Intent intent=new Intent(sample.this,MapsClonedActivity.class);
            intent.putExtra("latitude", lat);
            intent.putExtra("longitude", lng);
            startActivity(intent);
        }
    };
    private void openGallery()
    {
        Intent intent = new Intent();
        intent.setType("image/* ");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 5);

    }

    private void openGalleryVideo()
    {
        Intent intent = new Intent();
        intent.setType("video/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Video"), 10);

    }
    // Creating Method to get the selected image file Extension from File Path URI.
    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver();

        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();

        // Returning the file Extension.
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri)) ;

    }

    // Creating UploadImageFileToFirebaseStorage method to upload image on storage.
    public void UploadImageFileToFirebaseStorage() {

        // Checking whether FilePathUri Is empty or not.

           if(FilePathUri!=null && VideoPathUri==null)
            {
                // Setting progressDialog Title.
                progressDialog.setTitle("Image/Video is Uploading...");

                // Showing progressDialog.
                progressDialog.show();
                // Creating second StorageReference.
                 storageReferenceimage = storageReference.child(Storage_Path + System.currentTimeMillis() + "."
                        + GetFileExtension(FilePathUri));

                // Adding addOnSuccessListener to second StorageReference.
                storageReferenceimage.putFile(FilePathUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot1) {


                                imageURL=taskSnapshot1.getDownloadUrl().toString();
                               // Toast.makeText(sample.this, imageURL, Toast.LENGTH_LONG).show();
                                // Getting image name from EditText and store into string variable.
                                TempImageName = imageName.getText().toString().trim();
                                TempComment=Comment.getText().toString().trim();
                                rating=ratingBar.getRating();
                                //  category=show.getText().toString().trim();
                                //Toast.makeText(getApplicationContext(), "Image  "+category, Toast.LENGTH_LONG).show();
                                // Showing toast message after done uploading.
                                storelat=String.valueOf(lat);
                                storelng=String.valueOf(lng);

                                // Getting image upload ID.
                                        ImageUploadId = databaseReference.push().getKey();
                                ImageUploadInfo imageUploadInfo = new ImageUploadInfo(mAuth.getUid().toString(),
                                        TempImageName,imageURL,videoUrl,rating.toString(),TempComment,
                                        storelat,storelng,category,ImageUploadId);



                                // Adding image upload id s child element into databaseReference.
                                //databaseReference.child(ImageUploadId).setValue(imageUploadInfo);
                                databaseReference.child(mAuth.getUid()).child(ImageUploadId).setValue(imageUploadInfo);
                                progressDialog.dismiss();

                                if(shareCount==1)
                                {
                                    shareLocation();

                                }




                            }
                        })
                        // If something goes wrong .
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {

                                // Hiding the progressDialog.
                                progressDialog.dismiss();

                                // Showing exception erro message.
                                Toast.makeText(sample.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        })

                        // On progress change upload time.
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                                // Setting progressDialog Title.
                                progressDialog.setTitle("Image is Uploading...");

                            }
                        });

            }
          else  if(VideoPathUri!=null && FilePathUri==null)
            {
                // Setting progressDialog Title.
                progressDialog.setTitle("Image/Video is Uploading...");

                // Showing progressDialog.
                progressDialog.show();

                // Creating second StorageReference.
                storageReferencevideo = storageReference.child(Storage_Path + System.currentTimeMillis() + "."
                        + GetFileExtension(VideoPathUri));


                // Adding addOnSuccessListener to second StorageReference.
                storageReferencevideo.putFile(VideoPathUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot2) {

                                videoUrl=taskSnapshot2.getDownloadUrl().toString();
                              //  Toast.makeText(sample.this, videoUrl, Toast.LENGTH_LONG).show();

                                // Getting image name from EditText and store into string variable.
                                TempImageName = imageName.getText().toString().trim();
                                TempComment=Comment.getText().toString().trim();
                                rating=ratingBar.getRating();
                                //  category=show.getText().toString().trim();
                                //Toast.makeText(getApplicationContext(), "Image  "+category, Toast.LENGTH_LONG).show();
                                // Showing toast message after done uploading.
                                storelat=String.valueOf(lat);
                                storelng=String.valueOf(lng);
                                @SuppressWarnings("VisibleForTests")

                                // Getting image upload ID.
                                        String ImageUploadId = databaseReference.push().getKey();
                                ImageUploadInfo imageUploadInfo = new ImageUploadInfo(mAuth.getUid().toString(),
                                        TempImageName,imageURL,videoUrl,rating.toString(),TempComment,storelat,storelng,category,ImageUploadId);



                                // Adding image upload id s child element into databaseReference.
                                //databaseReference.child(ImageUploadId).setValue(imageUploadInfo);
                                databaseReference.child(mAuth.getUid()).child(ImageUploadId).setValue(imageUploadInfo);
                                progressDialog.dismiss();

                                if(shareCount==1)
                                {
                                    shareLocation();

                                }
                            }
                        })
                        // If something goes wrong .
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {

                                // Hiding the progressDialog.
                                progressDialog.dismiss();

                                // Showing exception erro message.
                                Toast.makeText(sample.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        })

                        // On progress change upload time.
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                                // Setting progressDialog Title.
                                progressDialog.setTitle("Video is Uploading...");

                            }
                        });

            }
            else if(FilePathUri!=null && VideoPathUri!=null)
           {
               // Setting progressDialog Title.
               progressDialog.setTitle("Image/Video is Uploading...");

               // Showing progressDialog.
               progressDialog.show();
               // Creating second StorageReference.
               storageReferenceimage = storageReference.child(Storage_Path + System.currentTimeMillis() + "."
                       + GetFileExtension(FilePathUri));
               storageReferencevideo = storageReference.child(Storage_Path + System.currentTimeMillis() + "."
                       + GetFileExtension(VideoPathUri));
               // Adding addOnSuccessListener to second StorageReference.
               storageReferenceimage.putFile(FilePathUri)
                       .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                           @Override
                           public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot1) {

                               progressDialog.dismiss();

                               imageURL=taskSnapshot1.getDownloadUrl().toString();
                               Toast.makeText(sample.this, imageURL, Toast.LENGTH_LONG).show();

                           }
                       })
                       // If something goes wrong .
                       .addOnFailureListener(new OnFailureListener() {
                           @Override
                           public void onFailure(@NonNull Exception exception) {

                               // Hiding the progressDialog.
                               progressDialog.dismiss();

                               // Showing exception erro message.
                               Toast.makeText(sample.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                           }
                       })

                       // On progress change upload time.
                       .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                           @Override
                           public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                               // Setting progressDialog Title.
                               progressDialog.setTitle("Image is Uploading...");

                           }
                       });

               storageReferencevideo.putFile(VideoPathUri)
                       .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                           @Override
                           public void onSuccess(final UploadTask.TaskSnapshot taskSnapshot1) {


                               videoUrl=taskSnapshot1.getDownloadUrl().toString();
                             //  Toast.makeText(sample.this, imageURL, Toast.LENGTH_LONG).show();
                               // Getting image name from EditText and store into string variable.
                               TempImageName = imageName.getText().toString().trim();
                               TempComment=Comment.getText().toString().trim();
                               rating=ratingBar.getRating();
                               //  category=show.getText().toString().trim();
                              // Toast.makeText(getApplicationContext(), "Image  "+category, Toast.LENGTH_LONG).show();
                               // Showing toast message after done uploading.
                               storelat=String.valueOf(lat);
                               storelng=String.valueOf(lng);
                               @SuppressWarnings("VisibleForTests")

                               // Getting image upload ID.
                                       String ImageUploadId = databaseReference.push().getKey();
                               ImageUploadInfo imageUploadInfo = new ImageUploadInfo(mAuth.getUid().toString(),
                                       TempImageName,imageURL,videoUrl,rating.toString(),TempComment,storelat,storelng,category,ImageUploadId);



                               // Adding image upload id s child element into databaseReference.
                               //databaseReference.child(ImageUploadId).setValue(imageUploadInfo);
                               databaseReference.child(mAuth.getUid()).child(ImageUploadId).setValue(imageUploadInfo);
                               progressDialog.dismiss();

                               if(shareCount==1)
                               {
                                   shareLocation();

                               }

                           }
                       })
                       // If something goes wrong .
                       .addOnFailureListener(new OnFailureListener() {
                           @Override
                           public void onFailure(@NonNull Exception exception) {

                               // Hiding the progressDialog.
                               progressDialog.dismiss();

                               // Showing exception erro message.
                               Toast.makeText(sample.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                           }
                       })

                       // On progress change upload time.
                       .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                           @Override
                           public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                               // Setting progressDialog Title.
                               progressDialog.setTitle("Image is Uploading...");

                           }
                       });

           }


    }


    public void shareLocation(){

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String whatsAppMessage;
                if(FilePathUri!=null && VideoPathUri==null)
                {
                    //Do something after 100ms
                     whatsAppMessage ="http://maps.google.com/maps?saddr="+ storelat + "," + storelng+
                            " \nPlace: "+TempImageName+"\n Longitude: "+storelat+"\n Latitude: "+storelng+
                            "\n Comment: "+TempComment+"\n Rating: "+rating+"\n Video link: No video";
                    //String whatsAppMessage = "http://maps.google.com/maps?saddr=" + storelat + "," + storelng;

                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
                    sendIntent.setType("text/plain");

                        sendIntent.putExtra(Intent.EXTRA_STREAM,FilePathUri);
                        sendIntent.setType("image/*");

                    startActivity(Intent.createChooser(sendIntent,"Share via"));
                    //startActivity(sendIntent);
                }

                else if(VideoPathUri!=null && FilePathUri==null)
                {
                    //Do something after 100ms
                    whatsAppMessage ="http://maps.google.com/maps?saddr="+ storelat + "," + storelng+
                            " \nPlace: "+TempImageName+"\n Longitude: "+storelat+"\n Latitude: "+storelng+
                            "\n Comment: "+TempComment+"\n Rating: "+rating+"\n Image: No image";
                    //String whatsAppMessage = "http://maps.google.com/maps?saddr=" + storelat + "," + storelng;

                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
                    sendIntent.setType("text/plain");

                        sendIntent.putExtra(Intent.EXTRA_STREAM,VideoPathUri);
                        sendIntent.setType("video/*");

                    startActivity(Intent.createChooser(sendIntent,"Share via"));
                    //startActivity(sendIntent);

                }
                else if(VideoPathUri!=null && FilePathUri!=null)
                {
                    //Do something after 100ms
                    whatsAppMessage ="http://maps.google.com/maps?saddr="+ storelat + "," + storelng+
                            " \nPlace: "+TempImageName+"\n Longitude: "+storelat+"\n Latitude: "+storelng+
                            "\n Comment: "+TempComment+"\n Rating: "+rating+"\n Video link: "+videoUrl;
                    //String whatsAppMessage = "http://maps.google.com/maps?saddr=" + storelat + "," + storelng;

                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
                    sendIntent.setType("text/plain");

                    sendIntent.putExtra(Intent.EXTRA_STREAM,FilePathUri);
                    sendIntent.setType("image/*");

                    startActivity(Intent.createChooser(sendIntent,"Share via"));
                    //startActivity(sendIntent);
                }


            }
        }, 2000);

    }


    // A place has been received; use requestCode to track the request.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 7 && resultCode == RESULT_OK && null != data) {
            FilePathUri=data.getData();
            //Toast.makeText(sample.this, (CharSequence) FilePathUri, Toast.LENGTH_LONG).show();

            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            // Set the image in ImageView*/
            ivGalImg.setImageBitmap(bitmap);
            ivGalImg.setScaleType(ImageView.ScaleType.FIT_XY);
            Toast.makeText(sample.this,"I got your image !!", Toast.LENGTH_LONG).show();

            // ivGalImg.setImageResource(R.drawable.i_got_it);
        }
        if (requestCode == 5 && resultCode == RESULT_OK && null != data) {
            // Get the url from data
            FilePathUri=data.getData();
            //Toast.makeText(sample.this, (CharSequence) FilePathUri, Toast.LENGTH_LONG).show();

            if (null != FilePathUri) {
                // Get the path from the Uri
                String path = getPathFromURI(FilePathUri);
                // Set the image in ImageView
                ivGalImg.setImageURI(FilePathUri);
                ivGalImg.setScaleType(ImageView.ScaleType.FIT_XY);
                Toast.makeText(sample.this,"I got your image !!", Toast.LENGTH_LONG).show();

                // ivGalImg.setImageResource(R.drawable.i_got_it);

            }
        }

        if (requestCode == 10 && resultCode == RESULT_OK && null != data) {
            VideoPathUri=data.getData();
            //Toast.makeText(sample.this, (CharSequence) VideoPathUri, Toast.LENGTH_LONG).show();

          /*  Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            // Set the image in ImageView*/
             video.setVideoURI(VideoPathUri);

            Toast.makeText(sample.this,"I got your video!!", Toast.LENGTH_LONG).show();
            video.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){
   public void onPrepared(MediaPlayer mp) {
       ProgressDialog progressBar=new ProgressDialog(sample.this);
       progressBar.dismiss();
       video.requestFocus();
       video.start();
   }
 });
        }

    }

    /* Get the real path from the URI */
    public String getPathFromURI(Uri contentUri) {
        String res = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }
    public  static final int RequestPermissionCode  = 1 ;

    public void EnableRuntimePermission(){

        if (ActivityCompat.shouldShowRequestPermissionRationale(sample.this,
                android.Manifest.permission.CAMERA))
        {

            Toast.makeText(sample.this,"CAMERA permission allows us to Access CAMERA app", Toast.LENGTH_LONG).show();

        } else {

            ActivityCompat.requestPermissions(sample.this,new String[]{
                    android.Manifest.permission.CAMERA}, RequestPermissionCode);

        }
    }

}
