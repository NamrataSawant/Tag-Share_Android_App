package com.example.namrata.tagnshare;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private TextInputLayout name;
    private TextInputLayout email;
    private TextInputLayout pass;
    private Button register;

    private Toolbar tool;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private ProgressDialog regProgressD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name=(TextInputLayout)findViewById(R.id.reg_name);
        email=(TextInputLayout)findViewById(R.id.reg_email);
        pass=(TextInputLayout)findViewById(R.id.reg_pass);
        register=(Button)findViewById(R.id.create_account);

        regProgressD=new ProgressDialog(this);

        tool=(Toolbar)findViewById(R.id.reg_page_toolbar) ;
        setSupportActionBar(tool);
        getSupportActionBar().setTitle("Create Account");
       // getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);


        mAuth = FirebaseAuth.getInstance();

        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                String mname=name.getEditText().getText().toString();
                String memail=email.getEditText().getText().toString();
                String mpass=pass.getEditText().getText().toString();

                if(!TextUtils.isEmpty(mname) || !TextUtils.isEmpty(memail) || !TextUtils.isEmpty(mpass)){

                    regProgressD.setTitle("Registering user");
                    regProgressD.setMessage("Please wait while we create your account");
                    regProgressD.setCanceledOnTouchOutside(true);
                    regProgressD.show();
                    register_user(mname,memail,mpass);

                }




            }
        });
    }

    private void register_user(final String mname, String memail, String mpass) {

        mAuth.createUserWithEmailAndPassword(memail,mpass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            FirebaseUser current_user=FirebaseAuth.getInstance().getCurrentUser();
                            String uid=current_user.getUid();
                            String token_id = FirebaseInstanceId.getInstance().getToken();


                            mDatabase=FirebaseDatabase.getInstance().getReference().child("Users").child(uid);
                            HashMap<String,String>usermap=new HashMap<String, String>();
                            usermap.put("device_token_id",token_id);
                            usermap.put("name",mname);
                            usermap.put("status","HI!");
                            usermap.put("image","DEFAULT");
                            usermap.put("thumb_image","DEFAULT");
                            usermap.put("online","true");
                            mDatabase.setValue(usermap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful())
                                    {
                                        regProgressD.dismiss();
                                        // Sign in success, update UI with the signed-in user's information
                                        Intent i=new Intent(RegisterActivity.this,MainActivity.class);
                                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);  //whenever in main activity after logged in should
                                        // go to register activity or any other back activity.Instead should close the app.
                                        startActivity(i);
                                        finish();
                                    }
                                }
                            });


                        } else {

                            regProgressD.hide();
                            // If sign in fails, display a message to the user.

                            Toast.makeText(RegisterActivity.this, "Cannot sign in please try again", Toast.LENGTH_SHORT).show();

                        }

                    // ...
                    }
                });


    }
}
