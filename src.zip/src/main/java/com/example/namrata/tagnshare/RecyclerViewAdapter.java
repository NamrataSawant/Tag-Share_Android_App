package com.example.namrata.tagnshare;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
/**
 * Created by Namrata on 14-Jan-18.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    String value;
    String user="me";
    Context context;
    List<ImageUploadInfo> MainImageUploadInfoList;
    List<Address> addresses;
    Geocoder geocoder;
    DatabaseReference mUsersDatabase;
    FirebaseUser mAuth;
    public RecyclerViewAdapter(Context context, List<ImageUploadInfo> TempList) {

        this.MainImageUploadInfoList = TempList;

        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_items, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
      final   ImageUploadInfo UploadInfo = MainImageUploadInfoList.get(position);

        mAuth= FirebaseAuth.getInstance().getCurrentUser();
        if(!(mAuth.getUid()).equals(UploadInfo.getUid()))
        {
            mUsersDatabase = FirebaseDatabase.getInstance().getReference()
                    .child("Users").child(UploadInfo.getUid());
            mUsersDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    user = String.valueOf(snapshot.child("name").getValue());
                    holder.user_name.setText("Uploaded by "+user);
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        }
        else
        {
            holder.user_name.setText("");

        }



        holder.imageNameTextView.setText(UploadInfo.getImageName());
     //   holder.imageNameTextViewLocation.setText("Comment:"+UploadInfo.getComment());
        holder.ratingBar.setRating(Float.parseFloat(UploadInfo.getRating()));
       /* if(UploadInfo.getVideoUrl()!=null) {
            Spanned Text1 = Html.fromHtml(UploadInfo.getVideoUrl());
            Toast.makeText(context, "Text:" + Text1, Toast.LENGTH_LONG).show();
            holder.videoUrl.setClickable(true);
            holder.videoUrl.setMovementMethod(LinkMovementMethod.getInstance());
            holder.videoUrl.setText(Text1);
        }

        final Double latitude,longitude;
        latitude=Double.valueOf(UploadInfo.getLatitude()) ;
        longitude=Double.valueOf(UploadInfo.getLongitude()) ;

        try {
            geocoder = new Geocoder(context, Locale.getDefault());

            addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
        } catch (IOException e) {
            e.printStackTrace();
        }
        String address1 = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
        String city = addresses.get(0).getLocality();
        String state = addresses.get(0).getAdminArea();
        String country = addresses.get(0).getCountryName();
        String postalCode = addresses.get(0).getPostalCode();
        Spanned Text = Html.fromHtml(" "+address1+" , "+city+" , "+state+" , "+country+" , "+postalCode);
        holder.address.setClickable(true);
        holder.address.setMovementMethod(LinkMovementMethod.getInstance());
        holder.address.setText(Text);*/
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(context,MoreDetailsActivity.class);
                intent.putExtra("name",UploadInfo.getImageName());
                intent.putExtra("category",UploadInfo.getCategory());
                intent.putExtra("comment",UploadInfo.getComment());
                intent.putExtra("imageUrl",UploadInfo.getImageURL());
                intent.putExtra("videoUrl",UploadInfo.getVideoUrl());
                intent.putExtra("latitude",UploadInfo.getLatitude());
                intent.putExtra("longitude",UploadInfo.getLongitude());
                intent.putExtra("rating",UploadInfo.getRating());
                intent.putExtra("uid",UploadInfo.getUid());
                intent.putExtra("user",user);
                intent.putExtra("imageUploadId",UploadInfo.getImageUploadId());
                view.getContext().startActivity(intent);
                /*Intent intent=new Intent(context,MapsClonedActivity.class);
                intent.putExtra("latitude",latitude);
                intent.putExtra("longitude",longitude);
               // ((Activity)context).startActivity(intent);
                view.getContext().startActivity(intent);*/

            }
        });

        if(UploadInfo.getImageURL()!=null) {
            //Loading image from Glide library.
            Glide.with(context).load(UploadInfo.getImageURL()).into(holder.imageView);
        }


    }

    @Override
    public int getItemCount() {

        return MainImageUploadInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder  {

       // public TextView imageNameTextViewLocation,address,videoUrl;
        public RatingBar ratingBar;
        public TextView imageNameTextView,user_name;
        public ImageView imageView;
       // public ImageView shareBtn,deletebtn;


        public ViewHolder(View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.imageView);
          //  videoUrl = (TextView) itemView.findViewById(R.id.videoUrl);
         //   videoUrl.setMovementMethod(LinkMovementMethod.getInstance());
            ratingBar=(RatingBar)itemView.findViewById(R.id.ratingBar2);
          //  address = (TextView) itemView.findViewById(R.id.address);
            imageNameTextView = (TextView) itemView.findViewById(R.id.ImageNameTextView);
          //  imageNameTextViewLocation = (TextView) itemView.findViewById(R.id.ImageNameTextView2);
            user_name = (TextView) itemView.findViewById(R.id.username);
         //   shareBtn=(ImageView) itemView.findViewById(R.id.shareBtn);
          //  deletebtn=(ImageView) itemView.findViewById(R.id.deletebtn);



        }




    }
}