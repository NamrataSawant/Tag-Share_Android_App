package com.example.namrata.tagnshare;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import com.google.firebase.messaging.RemoteMessage;

/**
 * Created by Dell on 10/01/2018.
 */

public class FirebaseMessagingService extends  com.google.firebase.messaging.FirebaseMessagingService {

  @Override
    public void onMessageReceived(RemoteMessage remoteMessage){
      super.onMessageReceived(remoteMessage);

    // For getting contents of notification function present in the json file.

    String notification_title = remoteMessage.getNotification().getTitle();
    String notification_message = remoteMessage.getNotification().getBody();

    String click_action = remoteMessage.getNotification().getClickAction(); // as specified in function and manifest file to
                                                                            // redirect to profile activity after click

    String from_user_id = remoteMessage.getData().get("from user_id");


    NotificationCompat.Builder mBuilder =
            new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.default_avatar) // app icon
                    .setContentTitle(notification_title)
                    .setContentText(notification_message);

    Intent resultIntent = new Intent(click_action); //from function
    resultIntent.putExtra("user_id",from_user_id);

    PendingIntent resultPendingIntent =
            PendingIntent.getActivity(
                    this,
                    0,
                    resultIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT
            );
    mBuilder.setContentIntent(resultPendingIntent);

             // Sets an ID for the notification
    int mNotificationId = 001;
             // Gets an instance of the NotificationManager service
    NotificationManager mNotifyMgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
           // Builds the notification and issues it.
    mNotifyMgr.notify(mNotificationId, mBuilder.build());

  }
}
