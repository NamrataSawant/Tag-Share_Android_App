package com.example.namrata.tagnshare;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by Dell on 02/07/2017.
 */
public class SectionsPagerAdapter  extends FragmentPagerAdapter {
    public SectionsPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {                          //position of fragment.
        switch (position){
            case 0:LinkToMap linktomapFragment=new LinkToMap();
                   return linktomapFragment;

            case 1:Locations locationFragment=new Locations();
                return locationFragment;


            case 2:FriendsFragment friendsFragment=new FriendsFragment();
                return friendsFragment;

            default:return null;


        }

    }

    @Override
    public int getCount() {
        return 3;               //number of fragments.
    }

    public CharSequence getPageTitle(int position){
        switch (position){
            case 0:return "Maps";
            case 1:return "Locations";
            case 2:return "Friends";
            default:return null;
        }
    }
}
