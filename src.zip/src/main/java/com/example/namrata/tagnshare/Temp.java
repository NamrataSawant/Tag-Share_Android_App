package com.example.namrata.tagnshare;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class Temp extends AppCompatActivity {
    String selectedCategory;
    // Creating DatabaseReference.
    DatabaseReference mFriendsDataReference;
    DatabaseReference mLocationsDataReference;
    DatabaseReference mFriendsNameDataReference;

    // Creating RecyclerView.
    RecyclerView recyclerView;

    // Creating RecyclerView.Adapter.
    RecyclerView.Adapter adapter ;
    // Creating Progress dialog

    ProgressDialog progressDialog;
    // Folder path for Firebase Storage.
    String Storage_Path = "All_Image_Uploads/";
    TextView username;

    // Root Database Name for Firebase Database.
   // String Database_Path = "Locations/";

    // Creating List of ImageUploadInfo class.
    List<ImageUploadInfo> list = new ArrayList<>();

    FirebaseUser mAuth;
    String friend_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp);
        list.clear();
        mLocationsDataReference = FirebaseDatabase.getInstance().getReference().child("Locations");

        Bundle extras = getIntent().getExtras();
        selectedCategory = extras.getString("category");

        // Assign id to RecyclerView.
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

        // Setting RecyclerView size true.
        recyclerView.setHasFixedSize(true);

        // Setting RecyclerView layout as LinearLayout.
        recyclerView.setLayoutManager(new LinearLayoutManager(Temp.this));

        // Assign activity this to progress dialog.
        progressDialog = new ProgressDialog(Temp.this);

        // Setting up message in Progress dialog.
        progressDialog.setMessage("Loading Images From Firebase.");

        // Showing progress dialog.
        progressDialog.show();

        // Setting up Firebase image upload folder path in databaseReference.
        // The path is already defined in MainActivity.
        // Toast.makeText(getApplicationContext(),""+mAuth.getUid(),Toast.LENGTH_SHORT).show();
        mAuth= FirebaseAuth.getInstance().getCurrentUser();
        mFriendsDataReference = FirebaseDatabase.getInstance().getReference().child("Friends").child(mAuth.getUid());

        // Adding Add Value Event Listener to databaseReference.
        //  databaseReference.child("comment").equalTo("best view and best place")
        mFriendsDataReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(final DataSnapshot snapshot) {

                for (DataSnapshot postSnapshot : snapshot.getChildren()) {

                     friend_id = postSnapshot.getKey();

                    mLocationsDataReference = FirebaseDatabase.getInstance().getReference().child("Locations").child(friend_id);
                    mLocationsDataReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {

                            for(DataSnapshot postSnapshot1: dataSnapshot.getChildren()){

                                ImageUploadInfo imageUploadInfo = postSnapshot1.getValue(ImageUploadInfo.class);
                                //onSelection();
                                boolean true1=imageUploadInfo.getCategory().equalsIgnoreCase(selectedCategory);
                                if(true1==true) {

                                    list.add(imageUploadInfo);
                                }
                                else continue;
                            }
                            adapter = new RecyclerViewAdapter(getApplicationContext(), list );

                            recyclerView.setAdapter(adapter);

                            // Hiding the progress dialog.
                            progressDialog.dismiss();

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

                // Hiding the progress dialog.
                progressDialog.dismiss();

            }
        });

    }


}